<html>
<head>
    <title>LD Sistemas </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/exemplo.css" rel="stylesheet" />
</head>
<body>
    <?php include_once("menu.php"); ?>