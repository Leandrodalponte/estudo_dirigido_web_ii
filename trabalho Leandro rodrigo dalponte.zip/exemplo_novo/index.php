<?php include_once("cabecalho.php"); ?>
    <h1>Gerenciamento de Funcionarios</h1>
<?php include_once("rodape.php"); ?>