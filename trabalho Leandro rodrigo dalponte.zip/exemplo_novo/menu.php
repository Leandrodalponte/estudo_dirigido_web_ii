<div class="navbar navbar-inverse navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <a href="index.php" class="navbar-brand">Inicio</a>
        </div>
        <div>
            <ul class="nav navbar-nav">
                <li><a href="funcionario-formulario.php">Cadastra Funcionario</a></li>
                <li><a href="funcionario-lista.php">Lista Funcionario</a></li>
                <li><a href="territorio-formulario.php">Cadastra Territorio</a></li>
                <li><a href="territorio-lista.php">Lista Territorios</a></li>
                <li><a href="func_territorio-formulario.php">Cadastro Territorio por Funcionario</a></li>
                <li><a href="func_territorio-lista.php">Territorios Funcionario</a></li>
                <li><a href="regiao-lista.php">Regiao</a></li>
            <ul>
        </div>
    </div>
</div>

<div class="container">
    <div class="principal">